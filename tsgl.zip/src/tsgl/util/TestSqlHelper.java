package tsgl.util;

import java.sql.*;
import javax.swing.JOptionPane;
public class TestSqlHelper {
   public static void main(String[] args) {
       Connection conn=SqlHelper.connect();
       if(conn!=null){
         JOptionPane.showMessageDialog(null, "���ݿ����ӳɹ�!");
         SqlHelper.closeConnection(conn);
       }else{
           JOptionPane.showMessageDialog(null, "���ݿ�����ʧ��!");
       }
   }
}

