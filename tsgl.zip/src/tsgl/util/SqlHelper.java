package tsgl.util;

import java.sql.*;
public class SqlHelper {
    public static Connection connect(){
        try{
            Class.forName("com.mysql.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/tsgl?useUnicode=true&amp;characterEncoding=utf8";
            Connection conn=DriverManager.getConnection(url,"root","aa17753466520");
           return conn;
        }catch(Exception e){
            e.printStackTrace();
            return null;
        }
     }

    public static void closeResultSet(ResultSet rs){
        try{
            rs.close();          
        }catch(Exception e){
            e.printStackTrace();           
        }
    } 
    
    public static void closePreparedStatement(PreparedStatement ps){
        try{
            ps.close();          
        }catch(Exception e){
            e.printStackTrace();           
        }
     }
    public static void closeConnection(Connection conn){
        try{
            conn.close();          
        }catch(Exception e){
            e.printStackTrace();           
        }
     }
 }

