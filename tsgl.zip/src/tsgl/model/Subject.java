package tsgl.model;

import java.util.Objects;

import tsgl.model.Subject;
public class Subject {
    private Integer subjectId;
    private String subjectName;

	public Integer getSubjectId() {
		return subjectId;
	}

	public void setSubjectId(Integer subjectId) {
		this.subjectId = subjectId;
	}

	public String getSubjectName() {
		return subjectName;
	}

	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	

	@Override
	public String toString() {
		return "Subject [subjectId=" + subjectId + ", subjectName=" + subjectName + ", getSubjectId()=" + getSubjectId()
				+ ", getSubjectName()=" + getSubjectName() + ", hashCode()=" + hashCode() + ", getClass()=" + getClass()
				+ ", toString()=" + super.toString() + "]";
	}

	@Override
    public boolean equals(Object obj) {        
        if (obj instanceof Subject) {
         final Subject other = (Subject) obj;
         return other.subjectId.equals(this.subjectId);
        }
       return this==obj;    
    }

 @Override
    public int hashCode() {
        int hash = 7;
        hash=89*hash+Objects.hashCode(this.subjectId);
        return hash;
    }


}

