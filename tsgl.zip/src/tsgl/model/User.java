package tsgl.model;

import java.sql.Date;
public class User {
    private Integer userId;
    private String userName;
    private String userPwd;
    private Date userDatetime;
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPwd() {
		return userPwd;
	}
	public void setUserPwd(String userPwd) {
		this.userPwd = userPwd;
	}
	public Date getUserDatetime() {
		return userDatetime;
	}
	public void setUserDatetime(Date userDatetime) {
		this.userDatetime = userDatetime;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userPwd=" + userPwd + ", userDatetime="
				+ userDatetime + ", getUserId()=" + getUserId() + ", getUserName()=" + getUserName() + ", getUserPwd()="
				+ getUserPwd() + ", getUserDatetime()=" + getUserDatetime() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}

    }
