package tsgl.model;

import java.sql.Date;
import java.util.Arrays;
public class Book {
    private String bookNo;
    private Subject subject;
    private String bName;
    private String bLanguage; 
    private String bAddress;
    private String bResume; 
    private Boolean bIsBorrowed;
    private byte[] bPic; 
    private Date bPublishDate;
	public String getBookNo() {
		return bookNo;
	}
	public void setBookNo(String bookNo) {
		this.bookNo = bookNo;
	}
	public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public String getbName() {
		return bName;
	}
	public void setbName(String bName) {
		this.bName = bName;
	}
	public String getbLanguage() {
		return bLanguage;
	}
	public void setbLanguage(String bLanguage) {
		this.bLanguage = bLanguage;
	}
	public String getbAddress() {
		return bAddress;
	}
	public void setbAddress(String bAddress) {
		this.bAddress = bAddress;
	}
	public String getbResume() {
		return bResume;
	}
	public void setbResume(String bResume) {
		this.bResume = bResume;
	}
	public Boolean getbIsBorrowed() {
		return bIsBorrowed;
	}
	public void setbIsBorrowed(Boolean bIsBorrowed) {
		this.bIsBorrowed = bIsBorrowed;
	}
	public byte[] getbPic() {
		return bPic;
	}
	public void setbPic(byte[] bPic) {
		this.bPic = bPic;
	}
	public Date getbPublishDate() {
		return bPublishDate;
	}
	public void setbPublishDate(Date bPublishDate) {
		this.bPublishDate = bPublishDate;
	}
	@Override
	public String toString() {
		return "Book [bookNo=" + bookNo + ", subject=" + subject + ", bName=" + bName + ", bLanguage=" + bLanguage
				+ ", bAddress=" + bAddress + ", bResume=" + bResume + ", bIsBorrowed=" + bIsBorrowed + ", bPic="
				+ Arrays.toString(bPic) + ", bPublishDate=" + bPublishDate + ", getBookNo()=" + getBookNo()
				+ ", getSubject()=" + getSubject() + ", getbName()=" + getbName() + ", getbLanguage()=" + getbLanguage()
				+ ", getbAddress()=" + getbAddress() + ", getbResume()=" + getbResume() + ", getbIsBorrowed()="
				+ getbIsBorrowed() + ", getbPic()=" + Arrays.toString(getbPic()) + ", getbPublishDate()="
				+ getbPublishDate() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
    

    }

