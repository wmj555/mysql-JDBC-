package tsgl.model;

import tsgl.model.Publisher;
import tsgl.model.Book;

public class Price {

	private Book book;
    private Publisher publisher;
    private Float price; 
    private  static Float avgPrice;
	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}
	public Publisher getPublisher() {
		return publisher;
	}
	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}
	public Float getPrice() {
		return price;
	}
	public void setPrice(Float price) {
		this.price = price;
	}
	public static Float getAvgPrice() {
		return avgPrice;
	}
	public static void setAvgPrice(Float avgPrice) {
		Price.avgPrice = avgPrice;
	}
	@Override
	public String toString() {
		return "Price [book=" + book + ", publisher=" + publisher + ", price=" + price + ", getBook()=" + getBook()
				+ ", getPublisher()=" + getPublisher() + ", getPrice()=" + getPrice() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
    
}
