package tsgl.model;

public class Publisher {
    private String publisherNo;
    private String publisherName;
    private String publisherLocate;
	public String getPublisherNo() {
		return publisherNo;
	}
	public void setPublisherNo(String publisherNo) {
		this.publisherNo = publisherNo;
	}
	public String getPublisherName() {
		return publisherName;
	}
	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}
	public String getPublisherLocate() {
		return publisherLocate;
	}
	public void setPublisherLocate(String publisherLocate) {
		this.publisherLocate = publisherLocate;
	}
	@Override
	public String toString() {
		return "Publisher [publisherNo=" + publisherNo + ", publisherName=" + publisherName + ", publisherLocate="
				+ publisherLocate + ", getPublisherNo()=" + getPublisherNo() + ", getPublisherName()="
				+ getPublisherName() + ", getPublisherLocate()=" + getPublisherLocate() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	


  }
