package tsgl.idao;

import java.util.List;
import tsgl.model.Subject;
public interface ISubjectDao {
    boolean addSubject(Subject subject);
    boolean deleteSubject(Integer subjectId);
    boolean editSubject(Subject subject);
    int findCount();//��ѯ���������ļ�¼����
    Subject findSubject(String subjectName);
    List<Subject> findSubjects(); 
}

