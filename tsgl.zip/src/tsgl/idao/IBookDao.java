package tsgl.idao;

import java.util.List;
import tsgl.model.Book;
public interface IBookDao {
   boolean addBook(Book book);
   boolean deleteBook(String bNo);
   boolean editBook(Book book);
   int findCount(String bName);
   Book findBook(String bNo);
   List<Book> findBooks(String bName,Integer pageNo,Integer pageSize);
}

