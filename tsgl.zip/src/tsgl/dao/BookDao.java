package tsgl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import tsgl.idao.IBookDao;
import tsgl.model.*;
import tsgl.util.SqlHelper;
public class BookDao  implements IBookDao{
     private Connection conn=null;
     private PreparedStatement ps=null;
     private ResultSet rs=null;  
     
   @Override
   public  Book findBook(String bNo){           
	   Book bb=null;
      try{
         conn=SqlHelper.connect();
         String sql="Select a.subject_name,b.* from tsgl_subject a,tsgl_book b where a.subject_id=b.subject_id and b_no=?";
         ps=conn.prepareStatement(sql);
         ps.setString(1, bNo);
         rs=ps.executeQuery();
         if(rs.next()){
             bb=new Book();
             Subject subject=new Subject();
             bb.setSubject(subject);
             subject.setSubjectId(rs.getInt(3));
             subject.setSubjectName(rs.getString(1));
             bb.setBookNo(rs.getString(2));
             bb.setbName(rs.getString(4));
             bb.setbLanguage(rs.getString(5));
             bb.setbPublishDate(rs.getDate(6));
             bb.setbIsBorrowed(rs.getBoolean(7));
             bb.setbAddress(rs.getString(8));
             bb.setbResume(rs.getString(9));
             bb.setbPic(rs.getBytes(10));  
            }           
       }catch(Exception e){
       
       }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);  
     }
      return bb;
   }
 

    @Override /*ʵ�ֳ��󷽷�findBooks()������������ҳ��ѯѧ��*/
   public  List<Book> findBooks(String bName, Integer pageNo, Integer pageSize){
       List<Book> list=new ArrayList<>();       
      try{ 
         conn=SqlHelper.connect();
         String sql="Select a.subject_name,b.* from tsgl_subject a,tsgl_book b where a.subject_id=b.subject_id and b_name like ? ";
                sql=sql+ " limit "+ (pageNo-1)* pageSize+","+pageSize;
         ps=conn.prepareStatement(sql);
         ps.setString(1, "%"+bName+"%");
         rs=ps.executeQuery();
         Book bb;
         while(rs.next()){
             bb=new Book();
             Subject subject=new Subject();
             bb.setSubject(subject);
             subject.setSubjectName(rs.getString(1));
             bb.setBookNo(rs.getString(2));
             subject.setSubjectId(rs.getInt(3));
             bb.setbName(rs.getString(4));
             bb.setbLanguage(rs.getString(5));
             bb.setbPublishDate(rs.getDate(6));
             bb.setbIsBorrowed(rs.getBoolean(7));
             bb.setbAddress(rs.getString(8));
             bb.setbResume(rs.getString(9));
             //b.setbPic(rs.getBytes(10)); 
             boolean add = list.add(bb);
         }          
      }catch(Exception e){         
  
      }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);           
     } 
       return list;
   }
   //����������ѯ��¼����
  @Override
   public  int findCount(String bName){
      int count=0;
        try{
         conn=SqlHelper.connect();
         String sql="Select count(*) as count from tsgl_book where b_name like ?";
         ps=conn.prepareStatement(sql);
         ps.setString(1, "%"+bName+"%");
         rs=ps.executeQuery();
         if(rs.next()){
             count=rs.getInt(1);
          }           
       }catch(Exception e){
       
       }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);  
     }     
       return count;
   }
   
    
  @Override
  public boolean addBook(Book book){
      boolean bln=false;
          try{
        conn=SqlHelper.connect();
        String sql="insert into tsgl_book(b_no,subject_id,b_name,b_language,b_publishDate,b_isborrowed,b_address,b_pic)";
               sql=sql + " values (?,?,?,?,?,?,?,?) ";
        ps=conn.prepareStatement(sql);
        ps.setString(1, book.getBookNo());
        ps.setInt(2, book.getSubject().getSubjectId());
        ps.setString(3, book.getbName());
        ps.setString(4, book.getbLanguage());
        ps.setDate(5, book.getbPublishDate());
        ps.setBoolean(6,book.getbIsBorrowed());
        ps.setString(7, book.getbAddress());
        ps.setBytes(8,book.getbPic());
        int n=ps.executeUpdate();          
        return n>0;     
      }catch(Exception e){
         return bln;
      }finally{
       SqlHelper.closePreparedStatement(ps);
       SqlHelper.closeConnection(conn);  
    }       
  }

   
  @Override
  public  boolean deleteBook(String bNo){
      boolean bln=false;
     try{
        conn=SqlHelper.connect();
        String sql="delete from tsgl_book where b_no=? ";
        ps=conn.prepareStatement(sql);
        ps.setString(1, bNo);         
        int n=ps.executeUpdate();          
        return n>0;     
      }catch(Exception e){
         return bln;
      }finally{
       SqlHelper.closePreparedStatement(ps);
       SqlHelper.closeConnection(conn);  
    }   
  }

  @Override
  public boolean editBook(Book book){
	   boolean bln=false;
     try{
        conn=SqlHelper.connect();
        String sql="update tsgl_book set subject_id=?,b_name=?,b_language=?,b_publishDate=?,b_isBorrowed=?,";
        sql=sql + "b_address=?,b_pic=? where b_no=?  ";
        ps=conn.prepareStatement(sql);       
        ps.setInt(1, book.getSubject().getSubjectId());
        ps.setString(2, book.getbName());
        ps.setString(3, book.getbLanguage());
        ps.setDate(4, book.getbPublishDate());
        ps.setBoolean(5,book.getbIsBorrowed());
        ps.setString(6, book.getbAddress());
        ps.setBytes(7,book.getbPic());
        ps.setString(8, book.getBookNo());
        int n=ps.executeUpdate();   
        return n>0;     
      }catch(Exception e){
          System.out.println(e);
         return bln;
      }finally{
         SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);  
    }       
  }
 


  
}