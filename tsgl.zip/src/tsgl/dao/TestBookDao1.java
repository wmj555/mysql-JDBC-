package tsgl.dao;

import java.sql.Date;
import java.util.List;
import tsgl.model.Subject;
import tsgl.model.Book;
public class TestBookDao1 {
    public static  void main(String[] ages){
        BookDao bdao=new BookDao();
        int count=bdao.findCount("");
        Book b=new Book();  
            
        System.out.println("\n����findBooks(bName, pageNo, pageSize)");
        List<Book> list=bdao.findBooks("",1, count);
        for(Book s:list)
            System.out.println(s);   
        
         Subject major=new Subject();
         major.setSubjectId(1);
         major.setSubjectName("����");
         b.setSubject(major);
         b.setBookNo("777");
         b.setbName("��������2");
         b.setbLanguage("��");
         b.setbIsBorrowed(true);
         Date date=new Date(95,1,20);         
         b.setbPublishDate(date);
         b.setbAddress("һ��ͼ���");
         System.out.println("\n����addBook(Book book)"); 
         System.out.println(bdao.addBook(b));
         
        count=bdao.findCount(""); 
        list=bdao.findBooks("",1, count);
        for(Book s:list)
            System.out.println(s);  
       
        System.out.println("\n����deleteBook(Book book)"); 
        System.out.println(bdao.deleteBook("777"));   
       
        count=bdao.findCount(""); 
        list=bdao.findBooks("",1, count);
        for(Book s:list)
            System.out.println(s);               
     
        System.out.println("\n����findBook(bNo)");
        String bNo="001";
        b=bdao.findBook(bNo);
        System.out.println(b);
          
        
        System.out.println("\n����editBook(Book book)"); 
        b.setbAddress("����ͼ���");
        System.out.println(bdao.editBook(b)); 
        b=bdao.findBook(bNo);
        System.out.println(b);           
    }    
}