package tsgl.dao;

import java.sql.*;
import java.util.ArrayList;
import tsgl.idao.*;
import java.util.List;
import javax.swing.JOptionPane;
import tsgl.model.Subject;
import tsgl.model.Book;
import tsgl.util.SqlHelper;

public class SubjectDao implements ISubjectDao{
    private Connection conn=null;
    private PreparedStatement ps=null;
    private ResultSet rs=null; 
    @Override
    public boolean addSubject(Subject subject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean deleteSubject(Integer subjectId) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean editSubject(Subject subject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int findCount() {
         int count=0;
        try{
         conn=SqlHelper.connect();
         String sql="Select count(*) as count from tsgl_subject ";
         ps=conn.prepareStatement(sql);       
         rs=ps.executeQuery();
         if(rs.next()){
             count=rs.getInt(1);
          }           
       }catch(Exception e){
       
       }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);  
     }     
       return count;
    }


    @Override
    public List<Subject> findSubjects() {
        List<Subject> list=new ArrayList<>();       
      try{ 
         conn=SqlHelper.connect();
         String sql="Select * from tsgl_subject ";             
         ps=conn.prepareStatement(sql);        
         rs=ps.executeQuery();
         Subject subject;
         while(rs.next()){
        	 subject=new Subject();
             subject.setSubjectId(rs.getInt(1));
             subject.setSubjectName(rs.getString(2));         
             boolean add = list.add(subject);
         }          
      }catch(Exception e){         
           JOptionPane.showMessageDialog(null, "û����ס����������¼��");
      }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);           
     } 
       return list;
   }  

    @Override
    public Subject findSubject(String subjectName) {
    	Subject subject=null;
      try{
         conn=SqlHelper.connect();
         String sql="Select * from tsgl_subject where subject_name=?";
         ps=conn.prepareStatement(sql);
         ps.setString(1, subjectName);
         rs=ps.executeQuery();
         if(rs.next()){
        	 subject=new Subject();                   
             subject.setSubjectId(rs.getInt(1));
             subject.setSubjectName(rs.getString(2));           
            }           
       }catch(Exception e){
       
       }finally{
        SqlHelper.closeResultSet(rs);
        SqlHelper.closePreparedStatement(ps);
        SqlHelper.closeConnection(conn);  
     }
      return subject;
    }
    }
