package tsgl.dao;

import java.util.List;
import tsgl.model.Book;
public class TestBookDao {
    public static  void main(String[] ages){
        BookDao bdao=new BookDao();
        System.out.println("\n����findCount(String bName)");  
          int count=bdao.findCount("");
          System.out.println(count+"����¼");
            
        System.out.println("\n����findBooks(bName, pageNo, pageSize)");
        System.out.println("\n����findBooks('', 1, 3)");
        List<Book> list=bdao.findBooks("",1, 3);
        for(Book s:list)
            System.out.println(s);
         
         System.out.println("\n����findBooks('', 2, 3)");
         list=bdao.findBooks("",2, 3);
         for(Book s:list)
            System.out.println(s);
         
       System.out.println("\n����findb(bNo)");
        String bNo="001";
        Book b=bdao.findBook(bNo);
        System.out.println(b);
        System.out.println();     
    }    
}
