package tsgl.view;

import java.awt.event.*;
import java.io.File;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import tsgl.dao.*;
import tsgl.model.*;
public class AddBook extends BookDialog implements ActionListener{
   public AddBook(){   
        this.setTitle("����ͼ�����ݴ���");
        this.addActionListener();     
   } 
   
   private void addActionListener(){
        btnOk.addActionListener(this);
        btnCancel.addActionListener(this);          
   }
   
   
    @Override
    public void actionPerformed(ActionEvent e) {
         if((e.getSource()).equals(btnOk)) { 
           try {
               SubjectDao subjectdao=new SubjectDao();               
               Subject subject=subjectdao.findSubject((String)comSubject.getSelectedItem());
               Book b=new Book();                 
               b.setBookNo(txtNo.getText().trim());
               b.setSubject(subject);
               b.setbName(txtName.getText().trim());
               b.setbLanguage(LanguageM.isSelected()?"��":"Ӣ");                  
               SimpleDateFormat date=new SimpleDateFormat("yyyy-mm-dd");
               b.setbPublishDate(new java.sql.Date(date.parse(txtPublishDate.getText()).getTime()));
               b.setbIsBorrowed(isBorrowed.isSelected()); 
               b.setbAddress(txtAddress.getText().trim());
               b.setbResume(txtResume.getText());
               BookDao bdao=new BookDao();  
               if(bdao.addBook(b)){
                    JOptionPane.showMessageDialog(null, "����ͼ��ɹ�");
                    dispose();
               }else{
                    JOptionPane.showMessageDialog(null, "����ͼ��ʧ��");
                    txtNo.requestFocus();
               }                   
             } catch (ParseException ex) {
               JOptionPane.showMessageDialog(null, "�������ݳ����쳣");
             }        
         }else{
            dispose();
         }       
    }    
    
}
