package tsgl.view;

import java.awt.*;
import java.io.*;
import javax.swing.*;
import tsgl.dao.*;
import tsgl.model.*;
public class BookDialog extends JDialog {
     protected String[] head={"���","��Ŀ","����","����","��������","����","�����ַ"};
     protected JLabel[]  labHead = new JLabel[7];
     protected JComboBox comSubject=new JComboBox();
     protected JRadioButton LanguageM=new JRadioButton("��");
     protected JRadioButton LanguageF=new JRadioButton("Ӣ");
     protected JTextField txtNo=new JTextField(5);
     protected JTextField txtName=new JTextField(10);
     protected JTextField txtPublishDate=new JTextField(10);
     protected JTextField txtAddress=new JTextField(25);
     protected JCheckBox isBorrowed=new JCheckBox();
     protected JTextArea  txtResume = new JTextArea();
   //  protected JPanel panelPic=new JPanel();
     protected JButton btnOk=new JButton("����");
     protected JButton btnCancel=new JButton("ȡ��");
     protected String filename;  
     protected Container con;
     public BookDialog(){
        con=this.getContentPane();  
        ButtonGroup group=new ButtonGroup();
        group.add(LanguageM); 
        group.add(LanguageF);
        LanguageM.setSelected(true);             
        this.loadSubject();        
        this.loadLayout();
        this.loadResume();
        this.loadButtom();
        this.setTitle("ͼ�鴰��");
        setSize(600, 500);//���ô�С
        setLocation(100, 100);//����λ��   
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); //���ùر���Ϊ
        setVisible(true);
     } 
  
     public final void  loadSubject(){
         SubjectDao dao=new SubjectDao(); 
         java.util.List<Subject> list=dao.findSubjects();
         for(Subject s:list) {
             comSubject.addItem(s.getSubjectName());
         }      
             }
     
      public final void  loadResume(){          
          JPanel center=new JPanel(new FlowLayout(FlowLayout.LEFT));
          center.add(new JLabel("���"));
          center.add(new JScrollPane(txtResume));                       
          txtResume.setColumns(40);
          txtResume.setRows(5);
          con.add(center,"Center");    
      }
      public final void  loadButtom(){     
         JPanel bottom=new JPanel(); 
         bottom.add(btnOk);
         bottom.add(btnCancel);        
         con.add(bottom,"South"); 
      }
       public final void  loadLayout(){
    
        JPanel top=new JPanel(new BorderLayout());
        JPanel topRight=new JPanel();
          
        JPanel topLeft=new JPanel(new GridLayout(7,1));  
        JPanel[] p=new JPanel[7];
        for(int i=0;i<7;i++){
            labHead[i]= new JLabel(head[i]+":");
            p[i]=new JPanel(new FlowLayout(FlowLayout.LEFT));
            p[i].add(labHead[i]);                        
            topLeft.add(p[i]);
            }        
         p[0].add(txtNo);
         p[1].add(comSubject);
         p[2].add(txtName);
         p[3].add(LanguageM);
         p[3].add(LanguageF);
         p[4].add( txtPublishDate);
         p[5].add(isBorrowed);
         p[6].add(txtAddress);              
         top.add(topLeft, "Center");
         top.add(topRight,"East");  
         con.add(top,"North");    
       }
     
}
