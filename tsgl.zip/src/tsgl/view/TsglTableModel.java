package tsgl.view;

import javax.swing.table.AbstractTableModel;
public class TsglTableModel extends AbstractTableModel {
    private final  Object[][] data;
    private final  String[] head;

     public TsglTableModel(String[] head,Object[][] data ) {
        this.data = data;
        this.head = head;       
    }   
          
    @Override
    public int getRowCount() {
        return  data.length; 
    }
    @Override
    public int getColumnCount() {
       return  head.length; 
    }
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return data[rowIndex][columnIndex];
    }   
     @Override
    public String getColumnName(int col) {
        return head[col];
    }
    
}
