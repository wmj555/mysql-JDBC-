package tsgl.view;

import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JPanel;

import tsgl.model.Book;
import tsgl.dao.BookDao;
public class ManageBook extends FindBook{
    JButton btnAdd=new JButton("����");
    JButton btnEdit=new JButton("�޸�");
    JButton btnDelete=new JButton("ɾ��");
    JPanel updata=new JPanel();
    String bNo;
    public  ManageBook(){
        updata.add(btnAdd);
        updata.add(btnEdit);
        updata.add(btnDelete);
        bottom.add(updata);
        this.setTitle("ͼ���������");
        btnAdd.addActionListener(this);
        btnEdit.addActionListener(this);
        btnDelete.addActionListener(this);   
        table.addMouseListener(new MouseAdapter(){
             @Override
             public void mousePressed(MouseEvent e){
              int row=table.getSelectedRow();
              if(row>=0){
                 bNo=table.getValueAt(row, 0).toString();                
               }  
             }                
         });      
       
                }
      @Override
    public void actionPerformed(ActionEvent e) {
        super.actionPerformed(e);
        if((e.getSource()).equals(btnAdd)){ 
              AddBook add=new  AddBook();
        }else if((e.getSource()).equals(btnEdit)){
              EditBook edit=new  EditBook(bNo);                 
           
        }else if((e.getSource()).equals(btnDelete)){
        	BookDao book = new BookDao();
        	book.deleteBook(bNo); 
        	//DeleteBook edit=new  DeleteBook(bNo);
       
        }

     }
}
