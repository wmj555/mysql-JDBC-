package tsgl.view;
import java.awt.event.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import tsgl.dao.*;
import tsgl.model.*;
public class DeleteBook extends BookDialog implements ActionListener{
	
	public DeleteBook(String bNo){   
	      btnOk.addActionListener(this);
	      btnCancel.addActionListener(this);
	      this.setTitle("ɾ��ͼ�����ݴ���");       
	      
	   }

	    @Override
	    public void actionPerformed(ActionEvent e) {
	         if((e.getSource()).equals(btnOk)) { 
	           try {
	               SubjectDao subjectdao=new SubjectDao();               
	               Subject subject=subjectdao.findSubject((String)comSubject.getSelectedItem());
	               Book b=new Book();                 
	               b.setBookNo(txtNo.getText().trim());
	               //b.setSubject(subject);
	               //b.setbName(txtName.getText().trim());
	              // b.setbLanguage(LanguageM.isSelected()?"��":"Ů");                  
	               SimpleDateFormat date=new SimpleDateFormat("yyyy-mm-dd");
	               b.setbPublishDate(new java.sql.Date(date.parse(txtPublishDate.getText()).getTime()));
	              // b.setbIsBorrowed(isBorrowed.isSelected()); 
	              // b.setbAddress(txtAddress.getText().trim());
	              // b.setbResume(txtResume.getText());
	               BookDao bookDao=new BookDao();      
	               boolean A = bookDao.deleteBook(b.getBookNo()); 
	               if(A){
	                    JOptionPane.showMessageDialog(null, "ɾ��ͼ�����ݳɹ�");
	                    dispose();
	               }else{
	                    JOptionPane.showMessageDialog(null, "ɾ��ͼ������ʧ��");
	                    txtNo.requestFocus();
	               }                   
	             } catch (ParseException ex) {
	               JOptionPane.showMessageDialog(null, "�������ݳ����쳣");
	             }        
	         }else{
	            dispose();
	         }       
	    }

}
