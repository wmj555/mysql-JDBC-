package tsgl.view;

import java.awt.*;
import javax.swing.*;
import tsgl.dao.*;
import tsgl.model.Book;
public class ShowBook extends JDialog{  
     String[] head={"���","��Ŀ","����","����","��������","����","�����ַ"};
     JLabel[]  labHead = new JLabel[10];
     JLabel[] txt=new JLabel[7];
     JTextArea   txtResume = new JTextArea();
  
     JPanel bottom=new JPanel(); 
     public ShowBook(String bNo) {
          Container container=this.getContentPane();       
               
          JPanel top=new JPanel(new BorderLayout());       
           JPanel topLeft=new JPanel(new GridLayout(7,1));  
           top.add(topLeft, "Center");         
           container.add(top,"North");
           
           JPanel[] p=new JPanel[7];
           for(int i=0;i<7;i++){
              labHead[i]= new JLabel(head[i]+":");
               txt[i]=new JLabel();       
              p[i]=new JPanel(new FlowLayout(FlowLayout.LEFT));
              p[i].add(labHead[i]);
              p[i].add(txt[i]);
              topLeft.add(p[i]);
           }             
          
           
         JPanel center=new JPanel(new FlowLayout(FlowLayout.LEFT));
         center.add(new JLabel("���"));
         center.add(new JScrollPane(txtResume));                
         container.add(center,"Center");          
         container.add(bottom,"South");
          
          txtResume.setEditable(false);  
          txtResume.setColumns(30);
          txtResume.setRows(5);
          
        this.loadData(bNo);
        this.setTitle("��ѯͼ�鴰��");
        this.setSize(360,360);
        this.setVisible(true);
      }
     
     public final void  loadData(String bNo){
        BookDao bookDao=new BookDao();      
         Book b=bookDao.findBook(bNo);
              txt[0].setText(b.getBookNo());
              txt[1].setText(b.getSubject().getSubjectName());
              txt[2].setText(b.getbName());
              txt[3].setText(b.getbLanguage());
              txt[4].setText(b.getbPublishDate().toString());
              txt[5].setText(b.getbIsBorrowed()?"��":"��");
              txt[6].setText(b.getbAddress());
      }      
     
}         
 
