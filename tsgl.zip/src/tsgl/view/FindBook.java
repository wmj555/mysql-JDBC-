package tsgl.view;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.List;
import tsgl.dao.*;
import tsgl.model.Book;
public class FindBook extends JFrame implements ActionListener{
    final static Integer PAGE_SIZE=5;
    BookDao bookDao=new BookDao();
    JTable table=new JTable();
    String[] head={"���","����","����","��������","����","�����ַ"};
    JTextField txtName=new JTextField(6);
    JButton btnFind=new JButton("����");
    JButton btnFirst=new JButton("��ҳ");
    JButton btnPrev=new JButton("��һҳ");
    JButton btnNext=new JButton("��һҳ");
    JButton btnLast=new JButton("ҳβ"); 
    JLabel labPageNo=new JLabel("ssss");
    String userName="";
    int pageCount=0,pageNo=0;
    int count;
    JPanel bottom=new JPanel(new BorderLayout());
    public FindBook() {
        Container con=this.getContentPane();
        JPanel top=new JPanel();
        top.add(new JLabel("����")); top.add(txtName); top.add(btnFind);
        con.add(top,"North");
        con.add(new JScrollPane(table),"Center");
        JPanel btn=new JPanel();
        btn.add(btnFirst);btn.add(btnPrev);btn.add(btnNext);btn.add(btnLast);
        btn.add(labPageNo);
         con.add(bottom,"South");
         bottom.add(btn,"North");       
      
          count=bookDao.findCount(userName);//��ѯ�ļ�¼����
         if(count>0){
            pageNo=1;
            pageCount=count/PAGE_SIZE+(count%PAGE_SIZE>0?1:0);             
        }         
        this.setState(); 
        this.loadData(userName,pageNo);//
        this.setTitle("��ѯͼ�鴰��");
        this.setSize(450,270);
        this.setVisible(true);
        this.addActionListener();
    } 
    private void addActionListener(){
          //����ťע�ᶯ��������
         btnFind.addActionListener(this);
         btnFirst.addActionListener(this);
         btnPrev.addActionListener(this);
         btnNext.addActionListener(this);
         btnLast.addActionListener(this);
        //������ע����������
         table.addMouseListener(new MouseAdapter(){
             @Override
             public void mouseClicked(MouseEvent e){
              int row=table.getSelectedRow();
              if(row>=0){
                 String bNo=table.getValueAt(row, 0).toString();
                 ShowBook showBook = new ShowBook(bNo);
               }  
             }                
         });         
    }
    public final void  loadData(String bName, int pageNo){
          List<Book> list =bookDao.findBooks(bName, pageNo,PAGE_SIZE);
          Object[][] data=convert(list);  
         table.setModel(new TsglTableModel(head,data));
      }
       
     private Object[][] convert(List<Book> list){
          Object[][] data=new Object[list.size()][6];  
          int i=0;
         for(Book b:list){
             data[i][0]=b.getBookNo();
             data[i][1]=b.getbName();
             data[i][2]=b.getbLanguage();
             data[i][3]=b.getbPublishDate();
             data[i][4]=b.getbIsBorrowed();
             data[i][5]=b.getbAddress();
            i++;
        }      
    return data;
}
      @Override
    public void actionPerformed(ActionEvent e) {
      if((e.getSource()).equals(btnFind)) { 
         userName=txtName.getText().trim();
         count=bookDao.findCount(userName);//��ѯ�ļ�¼����
         if(count>0){
            pageNo=1;
            pageCount=count/PAGE_SIZE+(count%PAGE_SIZE>0?1:0);
        }else{
           pageNo=0;
           pageCount=0; 
         }
       
      }else if((e.getSource()).equals(btnFirst))
             pageNo= 1;  
      else if((e.getSource()).equals(btnLast))
            pageNo= pageCount;         
      else if((e.getSource()).equals(btnNext)&&pageCount>pageNo)
                  pageNo++;         
      else  if((e.getSource()).equals(btnPrev)&&pageNo>1)
        pageNo--;       
        
      this.loadData(userName,  pageNo);
      setState();
    }
    
    private void setState() {        
        labPageNo.setText(pageNo+"/"+pageCount);
        if(pageNo==pageCount){
           btnLast.setEnabled(false);
           btnNext.setEnabled(false);
        }else{
           btnLast.setEnabled(true);
           btnNext.setEnabled(true);
        }
        if(pageNo<=1){
           btnFirst.setEnabled(false);
           btnPrev.setEnabled(false);
        }else{
           btnFirst.setEnabled(true);
           btnPrev.setEnabled(true);
        }        
    }  
 }
