package view;

import tsgl.view.ShowBook;
public class TestShowBook {
    public static void main(String[] args) {
         ShowBook showBook = new ShowBook("997");
    }   
    
}
