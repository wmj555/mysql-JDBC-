package view;

import tsgl.view.FindBook;
public class TestFindBook {
    public static void main(String[] args) {
        FindBook findBook = new FindBook();    
     
    }     
}