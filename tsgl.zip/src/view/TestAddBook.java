package view;

import tsgl.view.AddBook;
public class TestAddBook {
     public static void main(String[] args) {
       AddBook student = new AddBook();       
    }     
}
