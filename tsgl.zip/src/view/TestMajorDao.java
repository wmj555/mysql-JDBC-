package view;

import java.util.List;
import tsgl.dao.SubjectDao;
import tsgl.model.Subject;
public class TestMajorDao {
     public static void main(String[] args) {
          SubjectDao dao=new SubjectDao();
         System.out.println("\n����findSubjects()");    
         List<Subject> list=dao.findSubjects();
         for(Subject s:list)
           System.out.println(s);
         
          System.out.println("\n����findSubject()");   
          Subject m=dao.findSubject("��ѧ");
           System.out.println(m.getSubjectId());
           System.out.println(m);  
        
   }       
}

