package view;

import tsgl.view.*;
public class TestManageBook {
    public static void main(String[] args) {       
          ManageBook book = new ManageBook();       
    }     
}

