package view;

import tsgl.view.BookDialog;
public class TestBookDialog {
     public static void main(String[] args) {
        BookDialog book = new BookDialog();       
    }     
}
